<?php

if(isset($_POST['title'])){
    require '../db_conn.php';

    $title = $_POST['title'];

    if(empty($title)){
        header("Location: ../dashboard.php?mess=error");
    }else {
        $stmt = $conn->prepare("INSERT INTO todos(title) VALUE(?)");
        $res = $stmt->execute([$title]);

        if($res){
            header("Location: ../dashboard.php?mess=success"); 
        }else {
            header("Location: ../dashboard.php");
        }
        $conn = null;
        exit();
    }
}else {
    header("Location: ../dashboard.php?mess=error");
}