<?
if(isset($_POST['title'])){

    $title = $_POST['title'];
    $username_form = $_POST['username'];

    $servername = "localhost";
    $username = "root";
    $password = "admin";
    $dbname = "schooling";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    } 

    $sql = "INSERT INTO semesters (title, username)
        VALUES (?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $title, $username_form);

    if ($stmt->execute()) {
        header("Location: dashboard.php");
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}