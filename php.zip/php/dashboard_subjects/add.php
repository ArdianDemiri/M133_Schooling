<?
if(isset($_POST['title'])){

    $title = $_POST['title'];
    $username_form = $_POST['username'];
    $semester_id = $_POST['semester_id'];

    $servername = "localhost";
    $username = "root";
    $password = "admin";
    $dbname = "schooling";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    } 

    $sql = "INSERT INTO subjects (title, username, semester_id)
    VALUES (?, ?, ?)";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $title, $username_form, $semester_id);

    if ($stmt->execute()) {
        header("Location: dashboard.php");
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}