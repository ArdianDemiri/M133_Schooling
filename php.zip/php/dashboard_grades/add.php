<?
if(isset($_POST['rating'])){

    $rating = $_POST['rating'];
    $weighting = $_POST['weighting'];
    $subject_id = $_POST['subject_id'];
    $username_form = $_POST['username'];
    $title = $_POST['title'];

    $servername = "localhost";
    $username = "root";
    $password = "admin";
    $dbname = "schooling";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
    } 
    $sql = "INSERT INTO grades (title, weighting, rating, subject_id, username)
        VALUES (?, ?, ?, ?, ?)";

        $stmt = $conn->prepare($sql);
    $stmt->bind_param("sddis", $title, $weighting, $rating, $subject_id, $username_form);

    if ($stmt->execute()) {
        header("Location: dashboard.php");
    } else {
    echo "Error: " . $sql . "<br>" . $conn->error;
    }
    $conn->close();
}